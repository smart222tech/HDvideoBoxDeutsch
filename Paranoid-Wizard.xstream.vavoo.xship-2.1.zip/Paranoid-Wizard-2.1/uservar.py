'''#####-----Build File-----#####'''
buildfile = 'https://gist.githubusercontent.com/handsom3j4ck/de2a356e790328d8d94945468ce71f42/raw/builds.txt?=1'

'''#####-----Videos File-----#####'''
videos_url = 'http://CHANGEME'

'''#####-----Notification File-----#####'''
notify_url  = 'http://CHANGEME'

'''#####-----Changelog Directory-----#####'''
changelog_dir  = 'http://CHANGEME/'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
